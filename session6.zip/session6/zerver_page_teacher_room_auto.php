<?php

session_start();

$_SESSION["auto_room_param"] = '0';

?>